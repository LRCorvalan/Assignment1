#!/bin/bash

echo "Enter a department code and course number:"
read -r dept_code course_num
echo "Enter an enrollment change amount:"
read -r change_amt

filename="data/${dept_code^^}${course_num}.crs"
if [[ ! -f "$filename" ]]; then
    echo "ERROR: course not found"
    exit 1
fi

temp_file=$(mktemp)
{ read -r dept_line; read -r course_name; read -r sched_line; read -r hours_line; read -r size_line; } < "$filename"

new_size=$((size_line + change_amt))

echo "$dept_line" > "$temp_file"
echo "$course_name" >> "$temp_file"
echo "$sched_line" >> "$temp_file"
echo "$hours_line" >> "$temp_file"
echo "$new_size" >> "$temp_file"

mv "$temp_file" "$filename"
echo "$(date) ENROLLMENT: $dept_code $course_num $course_name changed by $change_amt" >> data/queries.log

