#!/bin/bash

mkdir -p data

echo "Enter department code:"
read -r dept_code
echo "Enter department name:"
read -r dept_name
echo "Enter course number:"
read -r course_num
echo "Enter course name:"
read -r course_name
echo "Enter course schedule (MWF/TH):"
read -r course_sched
echo "Enter course start date:"
read -r course_start
echo "Enter course end date:"
read -r course_end
echo "Enter credit hours:"
read -r course_hours
echo "Enter initial enrollment count:"
read -r course_size

filename="data/${dept_code^^}${course_num}.crs"
if [[ -f "$filename" ]]; then
    echo "ERROR: course already exists"
    exit 1
fi

echo "$dept_code $dept_name" > "$filename"
echo "$course_name" >> "$filename"
echo "$course_sched $course_start $course_end" >> "$filename"
echo "$course_hours" >> "$filename"
echo "$course_size" >> "$filename"

echo "$(date) CREATED: $dept_code $course_num $course_name" >> data/queries.log

