#!/bin/bash

total=$(ls data/*.crs 2>/dev/null | wc -l)
echo "Total course records: $total"

