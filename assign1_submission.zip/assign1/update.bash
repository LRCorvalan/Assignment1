#!/bin/bash

echo "Enter a department code and course number:"
read -r dept_code course_num

filename="data/${dept_code^^}${course_num}.crs"
if [[ ! -f "$filename" ]]; then
    echo "ERROR: course not found"
    exit 1
fi

temp_file=$(mktemp)

echo "Enter department name (or press Enter to keep current):"
read -r dept_name
echo "Enter course name (or press Enter to keep current):"
read -r course_name
echo "Enter course schedule (MWF/TH) (or press Enter to keep current):"
read -r course_sched
echo "Enter course start date (or press Enter to keep current):"
read -r course_start
echo "Enter course end date (or press Enter to keep current):"
read -r course_end
echo "Enter credit hours (or press Enter to keep current):"
read -r course_hours
echo "Enter initial enrollment count (or press Enter to keep current):"
read -r course_size

{ read -r old_dept_line; read -r old_course_name; read -r old_sched; read -r old_hours; read -r old_size; } < "$filename"

echo "${dept_code} ${dept_name:-${old_dept_line#* }}" > "$temp_file"
echo "${course_name:-$old_course_name}" >> "$temp_file"
echo "${course_sched:-${old_sched%% *}} ${course_start:-${old_sched#* }} ${course_end:-${old_sched##* }}" >> "$temp_file"
echo "${course_hours:-$old_hours}" >> "$temp_file"
echo "${course_size:-$old_size}" >> "$temp_file"

mv "$temp_file" "$filename"
echo "$(date) UPDATED: $dept_code $course_num $course_name" >> data/queries.log

