#!/bin/bash

echo "Enter a department code and course number:"
read -r dept_code course_num

filename="data/${dept_code^^}${course_num}.crs"
if [[ ! -f "$filename" ]]; then
    echo "ERROR: course not found"
    exit 1
fi

cat "$filename"

